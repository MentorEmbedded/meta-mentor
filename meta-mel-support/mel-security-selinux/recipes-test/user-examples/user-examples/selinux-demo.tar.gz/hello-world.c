#include <stdio.h>

int main()
{
	printf("***********************************\n");
	printf("********** Hello, world! **********\n");
	printf("***********************************\n");

	return 0;
} 
